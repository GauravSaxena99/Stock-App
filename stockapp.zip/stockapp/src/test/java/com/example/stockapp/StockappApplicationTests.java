package com.example.stockapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockappApplicationTests {

    @Test
    void contextLoads() {
    }
}