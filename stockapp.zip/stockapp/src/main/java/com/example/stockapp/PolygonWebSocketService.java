
package com.example.stockapp;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

@Service
public class PolygonWebSocketService {

    private final FirebaseDatabase firebaseDatabase;
    private WebSocketClient webSocketClient;

    public PolygonWebSocketService(FirebaseDatabase firebaseDatabase) {
        this.firebaseDatabase = firebaseDatabase;
    }

    public void connectToStockMarketData() {
        // WebSocket API endpoint (use a real one like Alpaca or a free stock data service)
        String stockMarketAPI = "wss://socket.polygon.io/stocks";

        try {
            webSocketClient = new WebSocketClient(new URI(stockMarketAPI)) {
                @Override
                public void onOpen(ServerHandshake handshake) {
                    System.out.println("Connected to the stock market WebSocket API");
                }

                @Override
                public void onMessage(String message) {
                    System.out.println("Received data: " + message);

                    // Parse the WebSocket message into a stock data map
                    Map<String, Object> stockData = parseStockData(message);

                    // Save the parsed stock data to Firebase
                    saveToFirebase(stockData);
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    System.out.println("WebSocket connection closed: " + reason);
                }

                @Override
                public void onError(Exception ex) {
                    System.err.println("Error in WebSocket connection: " + ex.getMessage());
                }
            };

            // Connect to the WebSocket API
            webSocketClient.connect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Map<String, Object> parseStockData(String data) {
        // Dummy implementation to parse JSON (replace this with actual parsing logic)
        // Example of incoming data: {"symbol": "AAPL", "price": 150.0, "open": 145.0, "high": 152.0, "close": 148.0}
        Map<String, Object> stockData = new HashMap<>();
        stockData.put("symbol", "AAPL"); // Extract actual data from the message
        stockData.put("currentPrice", 150.0);
        stockData.put("open", 145.0);
        stockData.put("high", 152.0);
        stockData.put("close", 148.0);

        return stockData;
    }

    private void saveToFirebase(Map<String, Object> stockData) {
        try {
            DatabaseReference reference = firebaseDatabase.getReference("stocks");
            reference.push().setValueAsync(stockData);
            System.out.println("Saved to Firebase: " + stockData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}