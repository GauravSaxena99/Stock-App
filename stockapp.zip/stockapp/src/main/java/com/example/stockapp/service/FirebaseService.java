package com.example.stockapp.service;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class FirebaseService {

    private final FirebaseDatabase firebaseDatabase;

    public FirebaseService(FirebaseDatabase firebaseDatabase) {
        this.firebaseDatabase = firebaseDatabase;
    }

    /**
     * Save stock data to Firebase.
     *
     * @param stockData The stock data to save.
     */
    public void saveStockData(Map<String, Object> stockData) {
        DatabaseReference reference = firebaseDatabase.getReference("stocks");
        reference.push().setValueAsync(stockData);
    }

    /**
     * Fetch all stock data from Firebase.
     *
     * @return A map containing all stock data.
     */
    public Map<String, Object> getAllStockData() {
        Map<String, Object> stockDataMap = new HashMap<>();
        DatabaseReference reference = firebaseDatabase.getReference("stocks");

        // Synchronously fetch data (blocking operation)
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    stockDataMap.put(snapshot.getKey(), snapshot.getValue());
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                throw new RuntimeException("Error fetching stock data: " + error.getMessage());
            }
        });

        return stockDataMap;
    }
}