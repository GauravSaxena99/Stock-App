package com.example.stockapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Objects;

@SpringBootApplication
@ComponentScan(basePackages = {"com.example.stockapp", "com.example.stockapp.service"})
public class StockappApplication {

    public static void main(String[] args) throws IOException {
        SpringApplication.run(StockappApplication.class, args);

        // Load Firebase credentials and initialize Firebase
        initializeFirebase();
    }

    private static void initializeFirebase() throws IOException {
        // Load the service account key from resources
        ClassLoader classLoader = StockappApplication.class.getClassLoader();
        File file = new File(Objects.requireNonNull(classLoader.getResource("serviceAccountKey.json")).getFile());

        // Initialize Firebase with credentials
        try (FileInputStream serviceAccount = new FileInputStream(file.getAbsolutePath())) {
            // FirebaseOptions constructor has changed, so using the latest method to initialize Firebase
            FirebaseOptions options = FirebaseOptions.builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .setDatabaseUrl("https://stockmanager-d19f7-default-rtdb.firebaseio.com") // Replace with your URL
                .build();

            // Initialize FirebaseApp
            if (FirebaseApp.getApps().isEmpty()) {
                FirebaseApp.initializeApp(options);
            }
        }
    }
}