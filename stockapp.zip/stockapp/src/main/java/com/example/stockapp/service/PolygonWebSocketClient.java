package com.example.stockapp.service;

import com.google.firebase.database.DatabaseReference;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map; // <-- Add this import

@SuppressWarnings("unused")
@Service("polygonWebSocketClientService")
public class PolygonWebSocketClient extends WebSocketClient {

    private final FirebaseService firebaseService;

    public PolygonWebSocketClient(FirebaseService firebaseService) throws URISyntaxException {
        super(new URI("wss://socket.polygon.io/stocks"));
        this.firebaseService = firebaseService;
    }

    @Override
    public void onOpen(ServerHandshake handshake) {
        System.out.println("WebSocket connection opened.");
        send("{\"action\":\"auth\",\"params\":\"2iGhmCYjm8eM9ur5NqfpbmusKcISpw0D\"}");
        send("{\"action\":\"subscribe\",\"params\":\"T.AAPL,T.MSFT,T.GOOG\"}"); // Example: Subscribe to 3 stock symbols
    }

    @Override
    public void onMessage(String message) {
        System.out.println("Received: " + message);
        // Assuming that the message is JSON and contains stock data
        Map<String, Object> stockData = parseStockData(message);
        firebaseService.saveStockData(stockData); // Save data to Firebase
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        System.out.println("WebSocket connection closed: " + reason);
    }

    @Override
    public void onError(Exception ex) {
        ex.printStackTrace();
    }

    private Map<String, Object> parseStockData(String message) {
        // Here you would parse the message from Polygon into a Map
        // For example, you can use a JSON library like Jackson or Gson to parse it
        // Here's a simple mock return:
        return Map.of("sym", "AAPL", "p", 150.25, "t", System.currentTimeMillis());
    }
}