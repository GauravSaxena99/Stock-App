package com.example.stockapp.websocket;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URISyntaxException;

@Service
public class PolygonWebSocketClient extends WebSocketClient {

    public PolygonWebSocketClient() throws URISyntaxException {
        super(new URI("wss://socket.polygon.io/stocks"));
    }

    @Override
    public void onOpen(ServerHandshake handshake) {
        System.out.println("WebSocket connection opened.");
        send("{\"action\":\"auth\",\"params\":\"2iGhmCYjm8eM9ur5NqfpbmusKcISpw0D\"}");
        send("{\"action\":\"subscribe\",\"params\":\"T.AAPL,T.MSFT\"}");
    }

    @Override
    public void onMessage(String message) {
        System.out.println("Received: " + message);
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        System.out.println("WebSocket connection closed: " + reason);
    }

    @Override
    public void onError(Exception ex) {
        ex.printStackTrace();
    }
}