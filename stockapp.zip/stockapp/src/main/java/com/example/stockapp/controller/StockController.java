package com.example.stockapp.controller;

import com.example.stockapp.service.FirebaseService;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api/stocks") // Base URL
@CrossOrigin("*")
public class StockController {

    private final FirebaseService firebaseService;

    public StockController(FirebaseService firebaseService) {
        this.firebaseService = firebaseService;
    }

    /**
     * Endpoint to fetch stock data from Firebase.
     * 
     * @return A map containing stock data fetched from Firebase.
     */
    @GetMapping
    public Map<String, Object> getStockData() {
        return firebaseService.getAllStockData();
    }
}